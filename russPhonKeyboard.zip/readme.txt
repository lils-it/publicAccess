
RUSSIAN PHONETIC KEYBOARD LAYOUT
================================

VERSION: 1.0.3.40

By: Andrey Aleksanyants, M.D.


Description
===========
Russian Phonetic Keyboard Layout allows you to type in Russian in the same way as you do when
typing in English, without having to learn the default Typewriter Layout coming with the system.

Russian Phonetic Layout works ONLY with Windows 2000 and higher (XP, Vista, 7, Server Systems).
Both 32 and 64 bit systems are supported.

Made with the Help of Microsoft Keyboard Layout Creator (MSKLC) 1.4 by Microsoft Corp.

--------------------------------------------------------------------------------

Installing
==========
1. Download ZIP file to your machine.
2. Extract all its files into any folder and run setup.exe file.
3. Open your Language Bar Settings*, select Russian if it is already displayed in
   your Language Bar, otherwise click 'Add' button and select Russian from 'Input Language'
   Section.
4. Select 'Russian (Phonetic)' Keyboard  Layout for 'Russian' and Press OK.
5. Restart your system if required.

* You can access this dialog either from language bar context menu or via Control Panel:
On Windows Vista & Windows 7:
1. Go to Start -> Control Panel -> Clock, Language, and Region -> Regional and Language Options
2. Switch to "Keyboards and Languages" tab and click on "Change keyboards..." button
3. The "Text services and input languages" dialog box should appear. Click on "Add..." button
4. In the "Add Input Languages" dialog box select "Russian" from "Input language" tree
   and opt-in "Russian (Phonetic)" keyboard layout
5. Click "OK".

On Windows XP:
1. Go to Start -> Control Panel -> Regional and Language Options
2. Select the "Language" tab in and click on "Details..." button
3. The "Text services and input languages"  dialog box  should appear. Click on "Add..." button
4. In the "Add Input Languages" dialog box select "Russian" from "Input language" dropdown menu
   and choose "Russian (Phonetic)" keyboard layout
5. Click "OK".

On Windows 2000:
1. Go to Start -> Settings -> Control Panel -> Regional Options
2. Select the "Input Locales" tab in the "Regional Options" dialog box
3. Click on "Add..." button
4. In the "Add Input Locale" dialog box select "Russian" from "Input locale" dropdown menu
   and choose "Russian (Phonetic)" keyboard layout
5. Click "OK"

IMPORTANT NOTICE FOR VISTA USERS: You need to temporary DISABLE UAC (User Account Control) when
installing the layout!
For detailed instructions, please refer to http://www.aleksanyants.com/dl/disable_uac.pdf

--------------------------------------------------------------------------------

Uninstalling
============
1. Disable Phonetic Keyboard Layout you want to uninstall from  Language Bar Settings by selec-
   ting it and pressing 'Remove' Button. 
2. Press 'Start' Button, enter Control Panel, double-click  'Add or Remove Programs' Icon, find
   'Russian (Phonetic)' entry, select and press 'Remove' Button and follow instructions. 
3. Now you can delete the downloaded file from directory you have saved it while downloading. 

--------------------------------------------------------------------------------

Freeware License
================
By installing, copying, or otherwise using the Software,  you agree to be bound by the terms of
this Agreement. If you do not agree  to the terms of this Agreement,  do not install or use the
Software.

This Software is provided "AS IS" and without warranty, express or implied.

This Software is being distributed as Freeware. It may be freely used,  copied  and distributed
as long as it is not sold, and all original files are included, including this license. You are
NOT allowed  to make a charge  for distributing  this  Software (either for profit or merely to
recover your media  and distribution costs) whether  as a stand-alone product,  or as part of a
compilation or anthology, without explicit prior written permission.

--------------------------------------------------------------------------------

Contact Information
===================
If you have some questions or suggestions you can contact me at aaleksanyants@yahoo.com.


